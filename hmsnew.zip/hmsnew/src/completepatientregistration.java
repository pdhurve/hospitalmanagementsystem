
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import com.csvreader.CsvWriter;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author pankaj
 */
public class completepatientregistration extends javax.swing.JFrame {

    /**
     * Creates new form completepatientregistration
     */
    public completepatientregistration() {
        initComponents();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        firstname = new javax.swing.JTextField();
        register = new javax.swing.JButton();
        lastname = new javax.swing.JTextField();
        email = new javax.swing.JTextField();
        password = new javax.swing.JPasswordField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        confirmpassword = new javax.swing.JPasswordField();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        address = new javax.swing.JTextArea();
        birthdate = new com.toedter.calendar.JDateChooser();
        jLabel6 = new javax.swing.JLabel();
        username = new javax.swing.JTextField();
        disease = new javax.swing.JTextField();
        contact = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Abyssinica SIL", 1, 24)); // NOI18N
        jLabel1.setText("patient registration");

        firstname.setText("firstname");

        register.setText("register");
        register.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                registerActionPerformed(evt);
            }
        });

        lastname.setText("lastname");

        email.setText("email address");

        jLabel3.setText("password");

        jLabel4.setText("confirm password");

        jLabel5.setText("date of birth");

        address.setColumns(20);
        address.setRows(5);
        address.setText("address");
        jScrollPane1.setViewportView(address);

        jLabel6.setText("username");

        disease.setText("disease");

        contact.setText("contact number");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel6)
                        .addGap(32, 32, 32)
                        .addComponent(username))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addGap(43, 43, 43)
                        .addComponent(password))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(firstname, javax.swing.GroupLayout.PREFERRED_SIZE, 215, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(44, 44, 44)
                        .addComponent(lastname, javax.swing.GroupLayout.DEFAULT_SIZE, 249, Short.MAX_VALUE))
                    .addComponent(email)
                    .addComponent(jScrollPane1)
                    .addComponent(register)
                    .addComponent(jLabel1)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4)
                            .addComponent(jLabel5))
                        .addGap(29, 29, 29)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(birthdate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(confirmpassword)))
                    .addComponent(disease)
                    .addComponent(contact))
                .addContainerGap(99, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addComponent(jLabel1)
                .addGap(49, 49, 49)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(firstname, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lastname, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(26, 26, 26)
                .addComponent(email, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(username, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(password, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(confirmpassword, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(23, 23, 23)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel5)
                    .addComponent(birthdate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28)
                .addComponent(disease, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 29, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(47, 47, 47)
                .addComponent(contact, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(43, 43, 43)
                .addComponent(register)
                .addGap(25, 25, 25))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    
    @SuppressWarnings("empty-statement")
    private void registration()
    {   

        try{   
            
            try{
                String Email=email.getText();
                String Password=Arrays.toString(password.getPassword());
                String Confirmpassword=Arrays.toString(confirmpassword.getPassword());
                String Contactnumber=contact.getText();
                String Address=address.getText();
                String dob=birthdate.getDate().toString();
                
                String Lastname=lastname.getText();
                String Username=username.getText();
                String Firstname=firstname.getText();
            }
            catch(java.lang.NullPointerException e)
            {
                JOptionPane.showMessageDialog(null,"Invalid input\n"+ "Try again.", "Registration Fail", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            
            String Email=email.getText();
            String Password=Arrays.toString(password.getPassword());
            String Confirmpassword=Arrays.toString(confirmpassword.getPassword());
            String Contactnumber=contact.getText();
            String Address=address.getText();
            String dob=birthdate.getDate().toString();
            String Lastname=lastname.getText();
            String Username=username.getText();
            String Firstname=firstname.getText();
            boolean validEmailAddress = isValidEmailAddress(Email);
            
            if(!validEmailAddress){
                JOptionPane.showMessageDialog(null,"Invalid Email.\n"+ "Try again with valid email.", "Registration Fail", JOptionPane.ERROR_MESSAGE);
                
                return;
            }
            
            
            boolean validpassword=Password.equals(Confirmpassword);
            
            if(!validpassword)
            {
                JOptionPane.showMessageDialog(null,"passwords do not match.\n"+ "Try again.", "Registration Fail", JOptionPane.ERROR_MESSAGE);
                
                return;
            }
            
            boolean validcontactnumber=isvalidcontact(Contactnumber);
            
            if(!validcontactnumber)
            {
                JOptionPane.showMessageDialog(null,"Invalid contact number.\n"+ "Try again with valid number.", "Registration Fail", JOptionPane.ERROR_MESSAGE);
                
                return;
            }
            
            String outputFile = "users.csv";
            boolean alreadyExists;
            alreadyExists = new File(outputFile).exists();
            
            try{
                String str2=Username+"issue.txt";
                PrintWriter writer = new PrintWriter(str2, "UTF-8");
                writer.println("");
                
                writer.close();
            } catch (IOException e) {
                // do something
            }
            try{
                CsvWriter csvOutput = new CsvWriter(new FileWriter(outputFile, true), ',');
                
                if (!alreadyExists)
                {
                    csvOutput.write("identity");
                    csvOutput.write("Firstname");
                    csvOutput.write("Lastname");
                    csvOutput.write("Contact number");
                    csvOutput.write("Username");
                    csvOutput.write("Email");
                    csvOutput.write("Password");
                    csvOutput.write("DOB");
                    csvOutput.write("Address");
                    csvOutput.write("specialisation");
                    csvOutput.write("degree");
                    
                    
                    csvOutput.endRecord();
                }
                // else assume that the file already has the correct header line
                
                // write out a few records
                csvOutput.write("Patient");
                csvOutput.write(Firstname);
                csvOutput.write(Lastname);
                csvOutput.write(Contactnumber);
                csvOutput.write(Username);
                csvOutput.write(Email);
                csvOutput.write(Password);
                csvOutput.write(dob);
                csvOutput.write(Address);
                csvOutput.write("N/A");
                csvOutput.write("N/A");
                
                
                
                csvOutput.endRecord();
                
                
                
                csvOutput.close();
                
                
            }
            catch (IOException e) {
            }
            boolean alreadyExists2;
            alreadyExists2 = new File("patientdoctor.csv").exists();
            CsvWriter csvOutput = new CsvWriter(new FileWriter("patientdoctor.csv", true), ',');
            if (!alreadyExists2)
            {
                csvOutput.write("patient");
                csvOutput.write("disease");
                csvOutput.write("doctor");
                csvOutput.endRecord();
            }
            csvOutput.write(Username);
            csvOutput.write(disease.getText());
            csvOutput.write("");
            csvOutput.endRecord();
            csvOutput.close();
            
            
            
            JOptionPane.showMessageDialog(null, "registration successful");
        }
        catch(IOException ex)
        {
            Logger.getLogger(completepatientregistration.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public boolean isValidEmailAddress(String Emailcheck){
           String regex = "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\])|(([a-zA-Z\\-0-9]+\\.)+[a-zA-Z]{2,}))$";
           
           java.util.regex.Pattern pattern = java.util.regex.Pattern.compile(regex);
           java.util.regex.Matcher matcher=pattern.matcher(Emailcheck);
           return matcher.matches();
    }
     public boolean isvalidcontact(String contact){
           String regex = "^[0-9]{10}$";
           
           java.util.regex.Pattern pattern = java.util.regex.Pattern.compile(regex);
           java.util.regex.Matcher matcher=pattern.matcher(contact);
           return matcher.matches();
    }
     
     
    private void registerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_registerActionPerformed
        registration();
        /*completepatientregistration form=new completepatientregistration();
        form.setVisible(true);
        dispose();*/
        this.setVisible(false);
    }//GEN-LAST:event_registerActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(completepatientregistration.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new completepatientregistration().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea address;
    private com.toedter.calendar.JDateChooser birthdate;
    private javax.swing.JPasswordField confirmpassword;
    private javax.swing.JTextField contact;
    private javax.swing.JTextField disease;
    javax.swing.JTextField email;
    private javax.swing.JTextField firstname;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField lastname;
    private javax.swing.JPasswordField password;
    private javax.swing.JButton register;
    private javax.swing.JTextField username;
    // End of variables declaration//GEN-END:variables
}
